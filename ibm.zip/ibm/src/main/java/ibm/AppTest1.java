package ibm;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.selenium.BrowserType;
import com.applitools.eyes.selenium.Configuration;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.fluent.Target;
import com.applitools.eyes.visualgrid.services.VisualGridRunner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AppTest1 {

	public static void main(String[] args) {

		String url1 = "https://demo.applitools.com/tlcHackathonMasterV1.html";	//prod test1

		// Create a new chrome web driver
		System.setProperty("webdriver.chrome.driver","C:\\aic virtual\\OTFAExecutionFiles\\chromedriver.exe");
		WebDriver webDriver = new ChromeDriver();
		JavascriptExecutor js = (JavascriptExecutor) webDriver;
		webDriver.manage().window().maximize();
		// Create a runner with concurrency of 1
		VisualGridRunner runner = new VisualGridRunner(1);

		// Create Eyes object with the runner, meaning it'll be a Visual Grid eyes.
		Eyes eyes = new Eyes(runner);
		setUp(eyes);

		webDriver.get(url1);	// Navigate to the url  test1 V1 production version
		
		// Call Open on eyes to initialize a test session
		eyes.open(webDriver, "AppliFashion", "Test 1", new RectangleSize(1200, 800));
		eyes.check(Target.window().fully().withName("main page"));			// Check the app page

		webDriver.findElement(By.id("SPAN__checkmark__107")).click();
		WebElement Element = webDriver.findElement(By.id("filterBtn"));//scroll to button filter and click
		js.executeScript("arguments[0].scrollIntoView();", Element);
		webDriver.findElement(By.id("filterBtn")).click();			
		WebElement Element1 = webDriver.findElement(By.id("product_grid"));
		eyes.checkRegion(Element1,"filter by color");		
		webDriver.findElement(By.id("resetBtn")).click();		//click on reset 
		webDriver.findElement(By.id("IMG__imgfluid__215")).click();
		eyes.check(Target.window().fully().withName("product details"));			// Check the app page

		// Call Close on eyes to let the server know it should display the results
		eyes.closeAsync();
		eyes.abortAsync();
		tearDown(webDriver, runner);
	}

	public static void setUp(Eyes eyes) {

		// Initialize eyes Configuration
		Configuration config = new Configuration();

		// You can get your api key from the Applitools dashboard
		config.setApiKey("G90jHD8W1051107Xk110Vxwj6SfFaQ0HLFaZrqZCpy6IfqPcM110");

		// create a new batch info instance and set it to the configuration
		config.setBatch(new BatchInfo("Holiday Shopping"));
		config.addBrowser(1200, 800, BrowserType.CHROME);
	
		// Set the configuration object to eyes
		eyes.setConfiguration(config);
	}

	private static void tearDown(WebDriver webDriver, VisualGridRunner runner) {

		webDriver.quit();	// Close the browser
		// we pass false to this method to suppress the exception that is thrown if we
		// find visual differences
		TestResultsSummary allTestResults = runner.getAllTestResults(false);
		System.out.println(allTestResults);
	}
}

